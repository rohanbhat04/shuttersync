import './gallery.css';

function Gallery(){
    return(
        <div>
            <div className='gallery'>
                <img src="" alt=""></img>
                <img></img>
            </div>
        </div>
    )
}

export default Gallery;